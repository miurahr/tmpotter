/* Russian Translation 
   Copyright (C) 2004-2005 Maxym Mykhalcuk <mihmax@netbeans.org> */

package com.sun.swing.internal.plaf.metal.resources;

import java.util.ListResourceBundle;

public final class metal_ru extends ListResourceBundle
{

    public metal_ru()
    {
    }

    protected final Object[][] getContents()
    {
        return contents;
    }

    private static final Object contents[][] = {
        {
            "FileChooser.detailsViewButtonAccessibleName", "\u0414\u0435\u0442\u0430\u043b\u0438"
        }, {
            "FileChooser.detailsViewButtonToolTipText", "\u0414\u0435\u0442\u0430\u043b\u0438"
        }, {
            "FileChooser.fileAttrHeaderText", "\u0410\u0442\u0440\u0438\u0431\u0443\u0442\u044b"
        }, {
            "FileChooser.fileDateHeaderText", "\u0418\u0437\u043c\u0435\u043d\u0435\u043d"
        }, {
            "FileChooser.fileNameHeaderText", "\u0418\u043c\u044f"
        }, {
            "FileChooser.fileNameLabelText", "\u0418\u043c\u044f \u0444\u0430\u0439\u043b\u0430:"
        }, {
            "FileChooser.fileSizeHeaderText", "\u0420\u0430\u0437\u043c\u0435\u0440"
        }, {
            "FileChooser.fileTypeHeaderText", "\u0422\u0438\u043f"
        }, {
            "FileChooser.filesOfTypeLabelText", "\u0424\u0430\u0439\u043b\u044b \u0442\u0438\u043f\u0430:"
        }, {
            "FileChooser.homeFolderAccessibleName", "\u0414\u043e\u043c"
        }, {
            "FileChooser.homeFolderToolTipText", "\u0414\u043e\u043c"
        }, {
            "FileChooser.listViewButtonAccessibleName", "\u0421\u043f\u0438\u0441\u043e\u043a"
        }, {
            "FileChooser.listViewButtonToolTipText", "\u0421\u043f\u0438\u0441\u043e\u043a"
        }, {
            "FileChooser.lookInLabelText", "\u0421\u043c\u043e\u0442\u0440\u0435\u0442\u044c \u0432:"
        }, {
            "FileChooser.newFolderAccessibleName", "\u0421\u043e\u0437\u0434\u0430\u0442\u044c \u043f\u0430\u043f\u043a\u0443"
        }, {
            "FileChooser.newFolderToolTipText", "\u0421\u043e\u0437\u0434\u0430\u043d\u0438\u0435 \u043d\u043e\u0432\u043e\u0439 \u043f\u0430\u043f\u043a\u0438"
        }, {
            "FileChooser.saveInLabelText", "\u0421\u043e\u0445\u0440\u0430\u043d\u044f\u0442\u044c \u0432:"
        }, {
            "FileChooser.upFolderAccessibleName", "\u0412\u0432\u0435\u0440\u0445"
        }, {
            "FileChooser.upFolderToolTipText", "\u041d\u0430 \u043e\u0434\u0438\u043d \u0432\u0432\u0435\u0440\u0445"
        }, {
            "InternalFrameTitlePane.closeButtonAccessibleName", "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"
        }, {
            "InternalFrameTitlePane.iconifyButtonAccessibleName", "\u0412 \u0438\u043a\u043e\u043d\u043a\u0443"
        }, {
            "InternalFrameTitlePane.maximizeButtonAccessibleName", "\u0420\u0430\u0437\u0432\u0435\u0440\u043d\u0443\u0442\u044c"
        }, {
            "MetalTitlePane.closeMnemonic", "67"
        }, {
            "MetalTitlePane.closeTitle", "\u0417\u0430\u043a\u0440\u044b\u0442\u044c (C)"
        }, {
            "MetalTitlePane.iconifyMnemonic", "69"
        }, {
            "MetalTitlePane.iconifyTitle", "\u0421\u0432\u0435\u0440\u043d\u0443\u0442\u044c (M)"
        }, {
            "MetalTitlePane.maximizeMnemonic", "88"
        }, {
            "MetalTitlePane.maximizeTitle", "\u0420\u0430\u0437\u0432\u0435\u0440\u043d\u0443\u0442\u044c (M)"
        }, {
            "MetalTitlePane.restoreMnemonic", "82"
        }, {
            "MetalTitlePane.restoreTitle", "\u0412\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c (R)"
        }
    };

}
